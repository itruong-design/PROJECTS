import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponentC as Home } from './home/home-component.component';
import { EmployeesComponentC as Employees} from './employees/employees-component.component';
import { PositionsComponentC as Positions} from './positions/positions-component.component';
import { PageNotFoundComponent as NotFound} from './page-not-found/page-not-found.component';


const routes: Routes = [
  {path: 'home', component: Home},
  {path: 'employees', component: Employees},
  {path: 'positions', component: Positions},
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: '**', component: NotFound}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
