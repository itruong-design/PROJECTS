import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponentC } from './nav/nav-component.component';
import { ContentComponentC } from './content/content-component.component';
import { FooterComponentC } from './footer/footer-component.component';
import { HomeComponentC } from './home/home-component.component';
import { EmployeesComponentC } from './employees/employees-component.component';
import { PositionsComponentC } from './positions/positions-component.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponentC,
    ContentComponentC,
    FooterComponentC,
    HomeComponentC,
    EmployeesComponentC,
    PositionsComponentC,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
