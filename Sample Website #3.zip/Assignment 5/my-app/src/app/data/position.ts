export class Position {
    _id: string;
    PostitionName: string;
    PositionDescription: string;
    PositionBaseSalary: number;
    __v: number;
}