import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Position } from './position';
import { Observable } from 'rxjs'; 

@Injectable({
  providedIn: 'root'
})
export class PositionsService {

  positionsURL = 'http://server-web422.herokuapp.com/positions';

  constructor(private http: HttpClient) { }

  getPositions(): Observable<Position[]> {
    return this.http.get<Position[]>(this.positionsURL);
  }
}
