import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeesComponentC } from './employees-component.component';

describe('EmployeesComponentC', () => {
  let component: EmployeesComponentC;
  let fixture: ComponentFixture<EmployeesComponentC>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeesComponentC ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeesComponentC);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
