import { Component, OnInit } from '@angular/core';
import { EmployeesService } from '../data/employees.service';
import { Employee } from '../data/employee';

@Component({
  selector: 'app-employees',
  templateUrl: './employees-component.component.html',
  styleUrls: ['./employees-component.component.css']
})
export class EmployeesComponentC implements OnInit {

  employees: Employee[];
  getEmployeesSub: any;
  loadingError: boolean = false;

  constructor(private EmployeesService: EmployeesService) { }

  ngOnInit() {
  this.getEmployeesSub = this.EmployeesService.getEmployees().subscribe(data => {
    this.employees = data;
  }, error => {
    this.loadingError = true;
  })
  }

  ngOnDestroy() {
    if(this.getEmployeesSub){
      this.getEmployeesSub.unsubscribe();
    }
  }
}
