import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterComponentC } from './footer-component.component';

describe('FooterComponentC', () => {
  let component: FooterComponentC;
  let fixture: ComponentFixture<FooterComponentC>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FooterComponentC ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponentC);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
