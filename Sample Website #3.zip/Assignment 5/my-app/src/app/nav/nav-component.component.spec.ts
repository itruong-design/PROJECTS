import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavComponentC } from './nav-component.component';

describe('NavComponentC', () => {
  let component: NavComponentC;
  let fixture: ComponentFixture<NavComponentC>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavComponentC ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavComponentC);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
