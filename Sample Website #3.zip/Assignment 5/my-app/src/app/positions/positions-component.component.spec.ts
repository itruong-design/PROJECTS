import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PositionsComponentC } from './positions-component.component';

describe('PositionsComponentC', () => {
  let component: PositionsComponentC;
  let fixture: ComponentFixture<PositionsComponentC>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PositionsComponentC ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PositionsComponentC);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
