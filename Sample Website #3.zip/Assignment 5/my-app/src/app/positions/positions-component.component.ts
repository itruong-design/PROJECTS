import { Component, OnInit } from '@angular/core';
import { PositionsService } from '../data/positions.service';
import { Position } from '../data/position';
 
@Component({
  selector: 'app-positions',
  templateUrl: './positions-component.component.html',
  styleUrls: ['./positions-component.component.css']
})
export class PositionsComponentC implements OnInit {

  positions: Position[];
  getPositionSub: any;
  loadingError: boolean = false;

  constructor(private PositionsService: PositionsService) { }

  ngOnInit() {
  this.getPositionSub = this.PositionsService.getPositions().subscribe(data => {
    this.positions = data;
  }, error => {
    this.loadingError = true;
  })
  }

  ngOnDestroy() {
    if(this.getPositionSub) {
      this.getPositionSub.unsubscribe();
    }
  }
}
